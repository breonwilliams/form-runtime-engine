<?php
/**
 * Autoloader for Form Runtime Engine classes.
 *
 * @package FormRuntimeEngine
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * PSR-4 style autoloader for FRE classes.
 */
class FRE_Autoloader {

    /**
     * Class mappings for namespaced classes.
     *
     * @var array
     */
    private static $class_map = array(
        // Core classes.
        'FRE_Registry'            => 'Core/class-fre-registry.php',
        'FRE_Renderer'            => 'Core/class-fre-renderer.php',
        'FRE_Shortcode'           => 'Core/class-fre-shortcode.php',
        'FRE_Submission_Handler'  => 'Core/class-fre-submission-handler.php',
        'FRE_Validator'           => 'Core/class-fre-validator.php',
        'FRE_Sanitizer'           => 'Core/class-fre-sanitizer.php',
        'FRE_Logger'              => 'Core/class-fre-logger.php',
        'FRE_Capabilities'        => 'Core/class-fre-capabilities.php',
        'FRE_Upgrader'            => 'Core/class-fre-upgrader.php',
        'FRE_Forms_Repository'    => 'Core/class-fre-forms-repository.php',
        'FRE_Conditions'          => 'Core/class-fre-conditions.php',

        // Connector classes (Phase 2+ Cowork connector).
        'FRE_Connector_Settings'  => 'Connector/class-fre-connector-settings.php',
        'FRE_Connector_Auth'      => 'Connector/class-fre-connector-auth.php',
        'FRE_Connector_API'       => 'Connector/class-fre-connector-api.php',
        'FRE_Connector_Admin'     => 'Connector/class-fre-connector-admin.php',
        'FRE_Connector_Log'       => 'Connector/class-fre-connector-log.php',

        // Database classes.
        'FRE_Migrator'            => 'Database/class-fre-migrator.php',
        'FRE_Entry'               => 'Database/class-fre-entry.php',
        'FRE_Entry_Query'         => 'Database/class-fre-entry-query.php',
        'FRE_Webhook_Log'         => 'Database/class-fre-webhook-log.php',

        // Field classes.
        'FRE_Field_Type'          => 'Fields/interface-fre-field-type.php',
        'FRE_Field_Type_Abstract' => 'Fields/abstract-fre-field-type.php',
        'FRE_Field_Text'          => 'Fields/class-fre-field-text.php',
        'FRE_Field_Email'         => 'Fields/class-fre-field-email.php',
        'FRE_Field_Tel'           => 'Fields/class-fre-field-tel.php',
        'FRE_Field_Textarea'      => 'Fields/class-fre-field-textarea.php',
        'FRE_Field_Select'        => 'Fields/class-fre-field-select.php',
        'FRE_Field_Radio'         => 'Fields/class-fre-field-radio.php',
        'FRE_Field_Checkbox'      => 'Fields/class-fre-field-checkbox.php',
        'FRE_Field_File'          => 'Fields/class-fre-field-file.php',
        'FRE_Field_Hidden'        => 'Fields/class-fre-field-hidden.php',
        'FRE_Field_Message'       => 'Fields/class-fre-field-message.php',
        'FRE_Field_Section'       => 'Fields/class-fre-field-section.php',
        'FRE_Field_Date'          => 'Fields/class-fre-field-date.php',
        'FRE_Field_Address'       => 'Fields/class-fre-field-address.php',

        // Security classes.
        'FRE_Honeypot'               => 'Security/class-fre-honeypot.php',
        'FRE_Timing_Check'           => 'Security/class-fre-timing-check.php',
        'FRE_Rate_Limiter'           => 'Security/class-fre-rate-limiter.php',
        'FRE_CSS_Validator'          => 'Security/class-fre-css-validator.php',
        'FRE_JSON_Schema_Validator'  => 'Security/class-fre-json-schema-validator.php',
        'FRE_Webhook_Validator'      => 'Security/class-fre-webhook-validator.php',

        // Webhook classes.
        'FRE_Webhook_Dispatcher'     => 'Webhooks/class-fre-webhook-dispatcher.php',

        // Upload classes.
        'FRE_Upload_Handler'      => 'Uploads/class-fre-upload-handler.php',
        'FRE_Mime_Validator'      => 'Uploads/class-fre-mime-validator.php',

        // Notification classes.
        'FRE_Email_Notification'  => 'Notifications/class-fre-email-notification.php',

        // Admin classes.
        'FRE_Admin'               => 'Admin/class-fre-admin.php',
        'FRE_Entries_List_Table'  => 'Admin/class-fre-entries-list-table.php',
        'FRE_Entry_Detail'        => 'Admin/class-fre-entry-detail.php',
        'FRE_CSV_Exporter'        => 'Admin/class-fre-csv-exporter.php',
        'FRE_Forms_Manager'       => 'Admin/class-fre-forms-manager.php',

        // Integration classes.
        'FRE_Design_System'       => 'Integration/class-fre-design-system.php',

        // Updates classes.
        'FRE_GitHub_Updater'      => 'Updates/class-fre-github-updater.php',

        // Twilio classes.
        'FRE_Twilio_Migrator'     => 'Twilio/class-fre-twilio-migrator.php',
        'FRE_Twilio_Validator'    => 'Twilio/class-fre-twilio-validator.php',
        'FRE_Twilio_Client'       => 'Twilio/class-fre-twilio-client.php',
        'FRE_SMS_Sender'          => 'Twilio/class-fre-sms-sender.php',
        'FRE_Twilio_Handler'      => 'Twilio/class-fre-twilio-handler.php',
        'FRE_Twilio_Admin'        => 'Twilio/class-fre-twilio-admin.php',
    );

    /**
     * Register the autoloader.
     */
    public static function register() {
        spl_autoload_register( array( __CLASS__, 'autoload' ) );
    }

    /**
     * Autoload a class.
     *
     * @param string $class_name Class name to load.
     */
    public static function autoload( $class_name ) {
        // Check if class is in our map.
        if ( isset( self::$class_map[ $class_name ] ) ) {
            $file = FRE_PLUGIN_DIR . 'includes/' . self::$class_map[ $class_name ];

            if ( file_exists( $file ) ) {
                require_once $file;
            }
        }
    }

    /**
     * Get field class name from field type.
     *
     * @param string $type Field type (e.g., 'text', 'email').
     * @return string|null Class name or null if not found.
     */
    public static function get_field_class( $type ) {
        $class_name = 'FRE_Field_' . ucfirst( $type );

        if ( isset( self::$class_map[ $class_name ] ) ) {
            return $class_name;
        }

        return null;
    }

    /**
     * Get all registered field types.
     *
     * @return array Array of field type slugs.
     */
    public static function get_field_types() {
        $types = array();

        foreach ( array_keys( self::$class_map ) as $class_name ) {
            if ( strpos( $class_name, 'FRE_Field_' ) === 0
                && $class_name !== 'FRE_Field_Type'
                && $class_name !== 'FRE_Field_Type_Abstract' ) {
                $types[] = strtolower( str_replace( 'FRE_Field_', '', $class_name ) );
            }
        }

        return $types;
    }
}

// Register the autoloader.
FRE_Autoloader::register();
