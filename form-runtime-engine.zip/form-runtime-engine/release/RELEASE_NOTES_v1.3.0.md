## Form Runtime Engine v1.3.0 — Cowork connector integration

This release packages the full **Claude Cowork connector** — a REST API, admin UI, and MCP server bridge that lets Claude Desktop create, update, delete, and (optionally) read form submissions on this WordPress site. Designed to work alongside the Promptless WP connector for end-to-end agency site-building workflows.

### Highlights

- **New REST API namespace** at `/wp-json/fre/v1/connector/` with 9 endpoints covering the full form-management and entry-read surface.
- **New admin page** — Form Entries → Claude Connection. Toggle the connector on, generate an Application Password, and copy a one-line bash command that installs the MCP server into Claude Desktop automatically.
- **Custom capability `fre_manage_forms`** replaces hardcoded `manage_options` checks at 22 form and entry call sites. Enables future delegation to non-admin roles without a cross-cutting refactor.
- **Form versioning foundation** for A/B analysis — every form now has a `connector_version` integer that bumps on save, and every submission is stamped with the version it was answered under.
- **Diagnostic preflight** — `formengine_preflight` returns plugin state, DB table health, and the last 5 connector call outcomes, so remote troubleshooting can happen from a single tool call.
- **Two-gate security model** — connector enable toggle and entry-read toggle are independent, both default off. Entry-read is a separate opt-in because submission data contains user PII.

### Verified end-to-end

All 9 MCP tools pressure-tested against a real production WordPress (`getflowmint.com`) over HTTPS + Basic Auth with WordPress Application Passwords. Full audit trail in `docs/CONNECTOR_TESTING_REPORT.md`.

### New documentation

- `docs/CONNECTOR_SPEC.md` — public REST API contract (v1)
- `docs/MCP_CONNECTOR_SETUP.md` — operator setup and host-specific troubleshooting
- `docs/CONNECTOR_TESTING_REPORT.md` — pressure-test artifact
- `docs/WORKFLOW_PROMPTLESS_INTEGRATION.md` — end-to-end agency pipeline when both connectors are installed
- `docs/COWORK_CONNECTOR_ASSESSMENT.md` — architectural rationale
- `docs/form-schema.json` — canonical form configuration schema
- `docs/AISB_TOKEN_CONTRACT.md` — Promptless design-token contract

### Installation

Download `form-runtime-engine-v1.3.0.zip` from the assets below. Upload via WordPress admin → Plugins → Add New → Upload Plugin. Activate.

The capability grant and version stamp happen automatically on first page load after activation. Existing installs upgrading from 1.2.x will have their pre-existing forms normalized on read — no manual migration needed.

### Changelog

Full details in `CHANGELOG.md`.
